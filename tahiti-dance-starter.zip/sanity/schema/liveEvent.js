export default {
  name: 'liveEvent',
  title: 'Live Event',
  type: 'document',
  fields: [
    { name: 'title', type: 'string', title: 'Title' },
    { name: 'description', type: 'text', title: 'Description' },
    { name: 'startTime', type: 'datetime', title: 'Start Time' },
    { name: 'endTime', type: 'datetime', title: 'End Time' },
    { name: 'priceCents', type: 'number', title: 'Price (cents)' },
    { name: 'currency', type: 'string', title: 'Currency', initialValue: 'EUR' },
    { name: 'muxLiveId', type: 'string', title: 'Mux Live ID' },
    { name: 'published', type: 'boolean', title: 'Published', initialValue: false }
  ]
}

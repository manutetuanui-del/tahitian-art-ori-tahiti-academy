export default {
  name: 'course',
  title: 'Course',
  type: 'document',
  fields: [
    { name: 'title', type: 'string', title: 'Title' },
    { name: 'description', type: 'text', title: 'Description' },
    { name: 'language', type: 'string', title: 'Language', options: { list: ['fr','en','jp','cn'] } },
    { name: 'lessons', type: 'array', of: [{ type: 'reference', to: [{ type: 'video' }] }] }
  ]
}

export default {
  name: 'video',
  title: 'Video',
  type: 'document',
  fields: [
    { name: 'title', type: 'string', title: 'Title' },
    { name: 'slug', type: 'slug', title: 'Slug', options: { source: 'title' } },
    { name: 'description', type: 'text', title: 'Description' },
    { name: 'level', type: 'string', title: 'Level', options: { list: ['Amateur','Intermédiaire','Professionnel'] } },
    { name: 'category', type: 'string', title: 'Category' },
    { name: 'muxAssetId', type: 'string', title: 'Mux Asset ID' },
    { name: 'durationSeconds', type: 'number', title: 'Duration (s)' },
    { name: 'language', type: 'string', title: 'Language', options: { list: ['fr','en','jp','cn'] } },
    { name: 'published', type: 'boolean', title: 'Published', initialValue: false }
  ]
}

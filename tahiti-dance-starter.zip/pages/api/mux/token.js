/**
 * API route to generate a signed playback token for Mux HLS playback.
 * This is a minimal example. In production use the official mux SDK and
 * create signed URLs or JWT tokens according to your Mux plan.
 */

export default async function handler(req, res) {
  if (req.method !== 'GET') return res.status(405).send('Method Not Allowed');

  const { assetId, userId } = req.query;
  if (!assetId || !userId) return res.status(400).json({ error: 'assetId and userId required' });

  // In production: verify user subscription in DB (Supabase) before issuing token.
  // Then use Mux signing keys to generate signed playback URL with short expiry.

  // Placeholder token (mock)
  const token = `mock-token-${assetId}-${userId}-${Date.now()}`;

  res.json({ token, playback_url: `https://stream.mux.com/${assetId}.m3u8?token=${token}` });
}

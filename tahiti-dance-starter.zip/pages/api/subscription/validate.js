/**
 * Validate subscription access for a given user and required level.
 * Example: request GET /api/subscription/validate?userId=...&level=Intermediaire
 * This endpoint checks subscriptions table (replace with real DB calls).
 */

export default async function handler(req, res) {
  if (req.method !== 'GET') return res.status(405).send('Method Not Allowed');

  const { userId, level } = req.query;
  if (!userId || !level) return res.status(400).json({ error: 'userId and level required' });

  // TODO: Replace with real DB query (Supabase)
  // For demo, we return allowed=true for any userId containing 'demo'
  const allowed = String(userId).includes('demo');

  res.json({ userId, level, allowed });
}

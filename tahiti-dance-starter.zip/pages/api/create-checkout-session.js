import Stripe from 'stripe';
const stripe = new Stripe(process.env.STRIPE_SECRET_KEY);

export default async function handler(req, res) {
  if (req.method !== 'POST') return res.status(405).end('Method Not Allowed');

  try {
    const { priceId, mode='subscription', successUrl = process.env.NEXT_PUBLIC_SITE_URL + '/success', cancelUrl = process.env.NEXT_PUBLIC_SITE_URL + '/cancel' } = req.body;

    if (!priceId) return res.status(400).json({error:'priceId required'});

    const session = await stripe.checkout.sessions.create({
      mode: mode, // 'subscription' or 'payment'
      line_items: [{ price: priceId, quantity: 1 }],
      success_url: successUrl + '?session_id={CHECKOUT_SESSION_ID}',
      cancel_url: cancelUrl,
      billing_address_collection: 'auto',
      payment_method_types: ['card'],
    });

    res.status(200).json({ url: session.url });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'internal_error', details: err.message });
  }
}

import Link from 'next/link';

export default function Home() {
  return (
    <main style={{fontFamily:'Arial, sans-serif', padding:24}}>
      <h1>Tāhiti Dance Academy — Starter</h1>
      <p>Bienvenue — ce projet est un squelette Next.js avec Stripe + Mux + Supabase stubs.</p>

      <section style={{marginTop:20}}>
        <h2>Démo</h2>
        <p><a href="/api/create-checkout-session">Create Checkout Session (API)</a> — use POST with priceId.</p>
      </section>

      <section style={{marginTop:20}}>
        <h3>Prochaines étapes</h3>
        <ol>
          <li>Configurer variables d'environnement dans <code>.env</code> ou Vercel env.</li>
          <li>Installer dépendances <code>npm install</code>.</li>
          <li>Lancer en local <code>npm run dev</code>.</li>
        </ol>
      </section>
    </main>
  )
}

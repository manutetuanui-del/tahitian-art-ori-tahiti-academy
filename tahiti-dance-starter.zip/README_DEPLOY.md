# Deploying to Vercel

1. Create a Git repository with this project and push to GitHub/GitLab.
2. Sign up or log in to Vercel and import the repository.
3. In Vercel project settings -> Environment Variables, add the variables from `.env.example`.
4. Deploy (Vercel will run `npm install` and `npm run build` automatically).
5. For Stripe webhooks: configure the webhook URL in Stripe dashboard to:
   - https://your-vercel-domain.vercel.app/api/webhooks/stripe
6. For local testing of webhooks, use `stripe listen` or `ngrok` to forward to your local dev server.


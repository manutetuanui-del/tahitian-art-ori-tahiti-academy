# Operation Playbook — Key Operations

## Add a new Video (Admin flow)
1. Record video and name files using standard: YYYYMMDD_title_language.mp4
2. Upload to Mux (via Mux upload API or direct upload UI)
3. Wait for encoding (Mux webhook 'asset.ready')
4. In Sanity, create a new Video document, set muxAssetId and metadata
5. Publish the video in Sanity
6. Test playback: request /api/mux/token?assetId=...&userId=...

## Publish a Live Event
1. In Sanity, create Live Event with startTime, price, and description
2. Create a Live in Mux via their API (get RTMP credentials)
3. Configure webhook for live events
4. Create a Stripe product/price for the live ticket or reuse generic ticket
5. Announce event via newsletter / social
6. At event time, stream via OBS -> Mux RTMP
7. After stream, verify replay saved and publish as VOD if desired

## Refund / Customer Support
1. Check Stripe payment id
2. Issue refund via Stripe Dashboard
3. Mark purchase in Supabase / purchases table as refunded
4. Send confirmation email to customer

## Daily checks
- Webhooks logs (Stripe/Mux) for errors
- Monitor Mux ingest and playback errors
- Monitor Supabase health
- Check new signups & cancellations


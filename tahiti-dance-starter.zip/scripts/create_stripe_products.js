/**
 * Script to create Stripe products & prices for subscriptions and one-time tickets.
 * Run locally: node scripts/create_stripe_products.js
 *
 * Requires STRIPE_SECRET_KEY env var.
 */
const Stripe = require('stripe');
const stripe = Stripe(process.env.STRIPE_SECRET_KEY);

async function run() {
  try {
    // Create plans
    const products = [
      { id: 'amateur', name: 'Tahitidance - Amateur', price_month: 12.00 },
      { id: 'intermediaire', name: 'Tahitidance - Intermédiaire', price_month: 25.00 },
      { id: 'pro', name: 'Tahitidance - Professionnel', price_month: 45.00 }
    ];

    for (const p of products) {
      console.log('Creating product', p.name);
      const prod = await stripe.products.create({ name: p.name, metadata: { tier: p.id } });
      const price = await stripe.prices.create({
        unit_amount: Math.round(p.price_month * 100),
        currency: 'eur',
        recurring: { interval: 'month' },
        product: prod.id
      });
      console.log(' -> Product created:', prod.id, 'price:', price.id);
    }

    // Example one-time ticket product
    const ticketProd = await stripe.products.create({ name: 'Live Ticket - Masterclass' });
    const ticketPrice = await stripe.prices.create({
      unit_amount: 1000, // 10.00 EUR
      currency: 'eur',
      product: ticketProd.id
    });
    console.log(' -> Ticket created:', ticketProd.id, ticketPrice.id);

    console.log('Done.');
  } catch (err) {
    console.error(err);
    process.exit(1);
  }
}

run();

# Tāhiti Dance Academy — Starter (Next.js + Stripe + Mux + Supabase)

This is a **starter scaffold** for the Tāhiti Dance Academy platform (100% cloud).
It includes a minimal Next.js app with example API routes for Stripe Checkout and Webhook,
and helper stubs for Mux & Supabase.

## What is included
- `pages/index.js` — landing page (minimal)
- `pages/api/create-checkout-session.js` — example Stripe Checkout creation (subscription or one-time)
- `pages/api/webhooks/stripe.js` — example webhook handler skeleton (verifies signature)
- `lib/stripe.js` — Stripe helper
- `lib/mux.js` — Mux helper stub
- `lib/supabase.js` — Supabase helper stub
- `.env.example` — environment variables you must set
- `package.json` — dependencies & scripts
- `next.config.js` — basic Next.js config

## How to use
1. Copy the folder to your machine or download the zip.
2. Create a project on Vercel and connect this repository, or run locally:
   - `npm install`
   - `npm run dev`
3. Set environment variables listed in `.env.example` (locally or in Vercel).
4. Configure Stripe (create products/prices) and set `STRIPE_SECRET_KEY` and `STRIPE_WEBHOOK_SECRET`.
5. Configure Mux & Supabase credentials.

## Deployment
- Recommended: Deploy on Vercel (link your GitHub repo -> Vercel -> set env vars -> Deploy).
- Make sure webhooks (Stripe, Mux) are routed to Vercel API endpoints (use `ngrok` for local testing).

## Notes
This scaffold is intentionally minimal and secure-by-design (webhook signatures are checked).
Extend the scaffold to add CMS integration (Sanity), auth (Clerk), and the full UI.



## Pack additions
- SQL schema and seed: `sql/schema.sql`, `sql/seed.sql`
- Mux token endpoint and subscription validation stubs
- Stripe product creation script: `scripts/create_stripe_products.js`
- Sanity schema files under `sanity/schema/`
- Checklist for account setup and operation playbook

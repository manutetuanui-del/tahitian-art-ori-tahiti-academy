# Checklist — Accounts & Initial Setup

## 1. Create cloud accounts
- [ ] Vercel (deploy Next.js) - invite team members
- [ ] Stripe (set country, business details)
- [ ] Mux (create project, get tokens)
- [ ] Supabase (create project & DB)
- [ ] Sanity (create project & datasets)
- [ ] Clerk (or Auth0) - create app credentials
- [ ] BunnyCDN (for China/edge)
- [ ] OPT bank account / business registration in PF

## 2. DNS & domain
- [ ] Buy domain (e.g. tahiti-dance.com) and configure DNS for Vercel
- [ ] Add SSL (Vercel handles)

## 3. Environment variables (Vercel)
- [ ] NEXT_PUBLIC_SITE_URL
- [ ] STRIPE_SECRET_KEY
- [ ] STRIPE_WEBHOOK_SECRET
- [ ] MUX_TOKEN_ID
- [ ] MUX_TOKEN_SECRET
- [ ] SUPABASE_URL
- [ ] SUPABASE_ANON_KEY
- [ ] SUPABASE_SERVICE_ROLE_KEY
- [ ] CLERK_FRONTEND_API
- [ ] BUNNY_API_KEY

## 4. Stripe configuration
- [ ] Create products & prices (run scripts/create_stripe_products.js)
- [ ] Setup webhook endpoint -> https://your-vercel-domain/api/webhooks/stripe
- [ ] Enable Alipay / WeChat in Stripe (if needed) and request access
- [ ] Configure tax settings if applicable

## 5. Supabase
- [ ] Run SQL schema (sql/schema.sql)
- [ ] Run seed data (sql/seed.sql)
- [ ] Configure Row Level Security (RLS) if needed
- [ ] Create service role key (store securely)

## 6. Mux
- [ ] Create asset key & playback policy
- [ ] Configure webhook endpoint to /api/mux/webhook
- [ ] Test upload and transcode

## 7. Sanity
- [ ] Deploy studio and import schema (sanity/schema)
- [ ] Create initial content (videos, courses, live events)

## 8. Local testing
- [ ] Populate .env.local with values from .env.example
- [ ] npm install
- [ ] npm run dev
- [ ] Test Stripe checkout (use test cards)
- [ ] Test webhooks with stripe listen

## 9. Team & access
- [ ] Add developers to GitHub & Vercel
- [ ] Add editors to Sanity
- [ ] Add accountant to Supabase / FenuaCompta (if needed)


-- Supabase / Postgres schema for Tahiti Dance Academy
-- Run in Supabase SQL editor or psql
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- users
CREATE TABLE IF NOT EXISTS users (
  id uuid PRIMARY KEY DEFAULT uuid_generate_v4(),
  email text UNIQUE NOT NULL,
  full_name text,
  created_at timestamptz DEFAULT now()
);

-- profiles (optional)
CREATE TABLE IF NOT EXISTS profiles (
  id uuid PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id uuid REFERENCES users(id) ON DELETE CASCADE,
  locale text DEFAULT 'fr',
  role text DEFAULT 'user',
  created_at timestamptz DEFAULT now()
);

-- subscriptions
CREATE TABLE IF NOT EXISTS subscriptions (
  id uuid PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id uuid REFERENCES users(id) ON DELETE CASCADE,
  stripe_subscription_id text,
  plan text,
  status text,
  current_period_start timestamptz,
  current_period_end timestamptz,
  created_at timestamptz DEFAULT now()
);

-- videos
CREATE TABLE IF NOT EXISTS videos (
  id uuid PRIMARY KEY DEFAULT uuid_generate_v4(),
  title text NOT NULL,
  slug text UNIQUE NOT NULL,
  description text,
  level text, -- Amateur / Inter / Pro
  category text,
  mux_asset_id text,
  duration_seconds integer,
  language text DEFAULT 'fr',
  published boolean DEFAULT false,
  created_at timestamptz DEFAULT now()
);

-- courses
CREATE TABLE IF NOT EXISTS courses (
  id uuid PRIMARY KEY DEFAULT uuid_generate_v4(),
  title text NOT NULL,
  description text,
  language text DEFAULT 'fr',
  created_at timestamptz DEFAULT now()
);

-- course lessons mapping
CREATE TABLE IF NOT EXISTS course_lessons (
  id uuid PRIMARY KEY DEFAULT uuid_generate_v4(),
  course_id uuid REFERENCES courses(id) ON DELETE CASCADE,
  video_id uuid REFERENCES videos(id),
  position integer DEFAULT 0
);

-- purchases (one-time)
CREATE TABLE IF NOT EXISTS purchases (
  id uuid PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id uuid REFERENCES users(id),
  stripe_payment_id text,
  product_type text,
  product_id text,
  amount_cents integer,
  currency text,
  created_at timestamptz DEFAULT now()
);

-- live events
CREATE TABLE IF NOT EXISTS live_events (
  id uuid PRIMARY KEY DEFAULT uuid_generate_v4(),
  title text NOT NULL,
  description text,
  mux_live_id text,
  start_time timestamptz,
  end_time timestamptz,
  price_cents integer DEFAULT 0,
  currency text DEFAULT 'EUR',
  published boolean DEFAULT false,
  created_at timestamptz DEFAULT now()
);

-- user progress
CREATE TABLE IF NOT EXISTS user_progress (
  id uuid PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id uuid REFERENCES users(id),
  video_id uuid REFERENCES videos(id),
  seconds_watched integer DEFAULT 0,
  completed boolean DEFAULT false,
  updated_at timestamptz DEFAULT now()
);

-- Indexes
CREATE INDEX IF NOT EXISTS idx_videos_level ON videos(level);
CREATE INDEX IF NOT EXISTS idx_subscriptions_user ON subscriptions(user_id);


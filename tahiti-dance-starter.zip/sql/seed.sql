-- Seed sample data (useful for local/dev)
INSERT INTO users (email, full_name) VALUES ('demo@tahitidance.test', 'Demo User') ON CONFLICT DO NOTHING;

INSERT INTO videos (title, slug, description, level, category, mux_asset_id, duration_seconds, language, published)
VALUES
('Ori Tahiti - Basic Step', 'ori-basic-step', 'Introduction to basic step', 'Amateur', 'Danse', 'mux-asset-demo-1', 420, 'fr', true),
('Pareo - How to tie', 'pareo-tying', 'Different pareo knots and styling', 'Amateur', 'Costume', 'mux-asset-demo-2', 180, 'fr', true)
ON CONFLICT DO NOTHING;

INSERT INTO courses (title, description) VALUES ('Parcours Débutant', 'Cours structuré pour débutants') ON CONFLICT DO NOTHING;

